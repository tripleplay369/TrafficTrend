window.trafficHistory = []
window.trend = ""
window.trendColor = "#a59e27"
window.currentInterval = null

function updateIcon() {
  var minutesToCheck = 15
  var threshold = 0.1

  var target = Date.now() - (minutesToCheck * 60 * 1000)

  var closest = null
  var smallestTimeDist = Number.MAX_VALUE

  var history = window.trafficHistory
  var newest = history[history.length - 1]
  for(var i = 0; i < history.length; ++i){
    var dist = Math.abs(target - history[i].timestamp)
    if(dist < smallestTimeDist){
      smallestTimeDist = dist
      closest = history[i]
    }
  }

  var thresholdTime = threshold * newest.trafficTime

  if(newest.trafficTime - closest.trafficTime < -thresholdTime){
    chrome.browserAction.setIcon({path: "green.png"})
    chrome.browserAction.setBadgeBackgroundColor({color: '#2f8d16'})
    window.trend = "Decreasing"
    window.trendColor = '#2f8d16'
  }
  else if(newest.trafficTime - closest.trafficTime > thresholdTime){
    chrome.browserAction.setIcon({path: "red.png"})
    chrome.browserAction.setBadgeBackgroundColor({color: '#bf1b1b'})
    window.trend = "Increasing"
    window.trendColor = '#bf1b1b'
  }
  else{
    chrome.browserAction.setIcon({path: "yellow.png"})
    chrome.browserAction.setBadgeBackgroundColor({color: '#a59e27'})
    window.trend = "Constant"
    window.trendColor = '#a59e27'
  }
}

function run() {
  var interval = 60000
  var retryInterval = 1000
  var maxHistoryLength = 30

  chrome.storage.sync.get(['start', 'end'], function(items){
    if(items['start'] && items['end']){
      var start = items['start']
      var end = items['end']

      var urlBase = "https://dev.virtualearth.net/REST/V1/Routes/Driving?o=json&optimize=timeWithTraffic&routeAttributes=routeSummariesOnly&key=ApOHeGHwYDdkH0nNTaK2ZpZxA0hC_6Lcwzq-RCbUZFw9-4MGOl3M1C56DUCTxunB"
      var url = urlBase + "&wp.0=" + encodeURIComponent(start) + "&wp.1=" + encodeURIComponent(end)

      var xhr = new XMLHttpRequest()
      xhr.open("GET", url, false)

      var parsed = null
      try{
        xhr.send()
        parsed = JSON.parse(xhr.response)
      }
      catch(err){}

      if(parsed && parsed.resourceSets.length > 0){

        var time = parsed.resourceSets[0].resources[0].travelDurationTraffic
        window.trafficHistory.push({timestamp: Date.now(), trafficTime: time})
        window.trafficHistory = window.trafficHistory.slice(-1 * maxHistoryLength)

        chrome.browserAction.setBadgeText({text: (time / 60).toFixed(0) + "m"})
        updateIcon()
        window.currentInterval = setTimeout(run, interval)
      }
      else{
        window.currentInterval = setTimeout(run, retryInterval)
      }
    }
  })
}

run()

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
  if(request.type == "get_history"){
    sendResponse({history: window.trafficHistory, trend: window.trend, trendColor: window.trendColor})
  }
  else if(request.type == "clear_history"){
    clearInterval(window.currentInterval)

    window.trafficHistory = []
    window.trendColor = "#a59e27"
    window.trend = ""
    chrome.browserAction.setIcon({path: "default.png"})

    chrome.browserAction.setBadgeText({text: ""})

    run()
  }
})
